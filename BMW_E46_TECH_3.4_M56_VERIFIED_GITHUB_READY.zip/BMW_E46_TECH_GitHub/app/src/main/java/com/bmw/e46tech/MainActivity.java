package com.bmw.e46tech;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

public class MainActivity extends Activity {
    private WebView web;
    private static final String DEEP_OBD_PACKAGE = "de.holeschak.bmw_deep_obd";
    private static final String DEEP_OBD_STORE = "https://play.google.com/store/apps/details?id=" + DEEP_OBD_PACKAGE;

    public class AndroidBridge {
        @JavascriptInterface
        public boolean openDeepObd() {
            final Intent launch = getPackageManager().getLaunchIntentForPackage(DEEP_OBD_PACKAGE);
            if (launch == null) return false;
            runOnUiThread(() -> startActivity(launch));
            return true;
        }
        @JavascriptInterface
        public void openDeepObdStore() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(DEEP_OBD_STORE))); }
                catch (Exception ignored) { }
            });
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(android.graphics.Color.rgb(16,24,32));
        w.setNavigationBarColor(android.graphics.Color.rgb(13,17,23));
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); if (web != null) web.saveState(out); }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { if (web != null) web.destroy(); super.onDestroy(); }
}
