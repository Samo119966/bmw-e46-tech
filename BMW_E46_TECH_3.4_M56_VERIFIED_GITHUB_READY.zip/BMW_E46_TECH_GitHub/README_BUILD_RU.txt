BMW E46 TECH 3.4 — Android WebView project

Проект Android с локальным офлайн-интерфейсом. Каталог 3.4 находится в app/src/main/assets/catalog_e46_m56_v34.json и catalog_e46_m56_v34.csv.

Сборка debug APK выполняется командой: gradle --no-daemon assembleDebug
Результат: app/build/outputs/apk/debug/app-debug.apk

Важно: приложение не является INPA и самостоятельно не подключается к ЭБУ. Раздел Deep OBD открывает отдельное приложение, если оно установлено.
